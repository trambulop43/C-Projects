/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;
import java.io.*;
/**
 *
 * @author objprog
 */
public class Employee implements Serializable{
    private String Fname;
    private String Lname;
    private job job;
    private int no;

    public Employee(String Fname, String Lname, job job, int no) {
        this.Fname = Fname;
        this.Lname = Lname;
        this.job = job;
        this.no = no;
    }

    public void setFname(String Fname) {
        this.Fname = Fname;
    }

    public void setLname(String Lname) {
        this.Lname = Lname;
    }

    public void setJob(job job) {
        this.job = job;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public String getFname() {
        return Fname;
    }

    public String getLname() {
        return Lname;
    }

    public job getJob() {
        return job;
    }

    public int getNo() {
        return no;
    }
}
